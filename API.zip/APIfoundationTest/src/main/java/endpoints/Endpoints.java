package endpoints;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.model;
import payload.model.Data;

public class Endpoints {
	 //Method to create a new object
	 public static Response createData(model data) {
	   RestAssured.useRelaxedHTTPSValidation();
	   Response response = RestAssured.given()
	           .headers("Content-Type", "application/json", "Accept", ContentType.JSON)
	           .baseUri(Routes.BASE_URI)
	           .basePath(Routes.POST_BASE_PATH)	         
	           .body(data)
	           .when()
	           .post();
	   return response;
	 }

	 // Method to get all data 
	 public static Response getAllData() {
	   RestAssured.useRelaxedHTTPSValidation();
	   Response response = RestAssured.given()
	           .baseUri(Routes.BASE_URI)
	           .basePath(Routes.GET_ALL_BASE_PATH)
	           .accept(ContentType.JSON)
	           .when()
	           .get();
	   return response;
	 }

	 // Method to get a single ID
	 public static Response getSingleData(int i) {
	   RestAssured.useRelaxedHTTPSValidation();
	   Response response = RestAssured.given()
	           .baseUri(Routes.BASE_URI)
	           .basePath(Routes.GET_BASE_PATH_ID)
	           .pathParam("id", i)
	           .accept(ContentType.JSON)
	           .when()
	           .get();
	   return response;
	 }


	 // Method to update an existing data by ID
	 public static Response updateData(String string) {
	   File payload1=new File(System.getProperty("user.dir")+"\\src\\main\\java\\payLoad\\payload.json");
	   RestAssured.useRelaxedHTTPSValidation();
	   Response response = RestAssured.given()
	           .headers("Content-Type", "application/json", "Accept", ContentType.JSON)
	           .baseUri(Routes.BASE_URI)
	           .basePath(Routes.UPDATE_BASE_PATH)
	           .pathParam("id", string)
	           .body(payload1)
	           .when()
	           .put();
	   return response;
	 }

	 // Method to delete by ID
	 public static Response deleteData(String string) {
	   RestAssured.useRelaxedHTTPSValidation();
	   Response response = RestAssured.given()
	           .baseUri(Routes.BASE_URI)
	           .basePath(Routes.DELETE_BASE_PATH)
	           .pathParam("id", string)
	           .when()
	           .delete();
	   return response;
	 }
  
}








































