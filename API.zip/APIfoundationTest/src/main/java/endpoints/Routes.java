package endpoints;

public class Routes {

public static String BASE_URI = "https://api.restful-api.dev/";
public static String GET_BASE_PATH_ID = "objects/{id}";
public static String GET_ALL_BASE_PATH= "objects";
public static String POST_BASE_PATH = "objects";
public static String UPDATE_BASE_PATH = "objects/{id}";
public static String DELETE_BASE_PATH = "objects/{id}";

}


































