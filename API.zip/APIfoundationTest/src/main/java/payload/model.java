package payload;

public class model {
    private String name;
    private Data data;

    public model() {
		super();
		// TODO Auto-generated constructor stub
	}

	// Constructor
    public model(String name, Data data) {
        this.name = name;
        this.data = data;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    // Inner class representing the nested data object
    public static class Data {
        private int year;
        private double price;
        private String cpuModel;
        private String hardDiskSize;
        private String color;

        public Data() {
			super();
			// TODO Auto-generated constructor stub
		}

		// Constructor
        public Data(int year, double price, String cpuModel, String hardDiskSize, String color) {
            this.year = year;
            this.price = price;
            this.cpuModel = cpuModel;
            this.hardDiskSize = hardDiskSize;
            this.color = color;
        }

        // Getters and Setters
        public int getYear() {
            return year;
        }

        public void setYear(int year) {
            this.year = year;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public String getCpuModel() {
            return cpuModel;
        }

        public void setCpuModel(String cpuModel) {
            this.cpuModel = cpuModel;
        }

        public String getHardDiskSize() {
            return hardDiskSize;
        }

        public void setHardDiskSize(String hardDiskSize) {
            this.hardDiskSize = hardDiskSize;
        }

        public String getColor() {
            return color;
        }

        public void setColor(String color) {
            this.color = color;
        }
    }

    // toString method for easy display
    @Override
    public String toString() {
        return "model{" +
                "name='" + name + '\'' +
                ", data=" + data +
                '}';
    }

    public static void main(String[] args) {
        // Example instantiation
        Data data = new Data(2019, 2049.99, "Intel Core i9", "1 TB", "silver");
        model Model = new model("Apple MacBook Pro 16", data);
        System.out.println(Model);
    }

}




//package payload;
//
//public class model {
//private String name;
//private String data;
//private int year;
//private double price;
//private String CPUmodel;
//private String hardiskSize;
//private String color;
//public String getName() {
//	return name;
//}
//public void setName(String name) {
//	this.name = name;
//}
//
//public model(String name, String data) {
//	super();
//	this.name = name;
//	this.data = data;
//}
//public int getYear() {
//	return year;
//}
//public void setYear(int year) {
//	this.year = year;
//}
//public double getPrice() {
//	return price;
//}
//public void setPrice(double price) {
//	this.price = price;
//}
//public String getCPUmodel() {
//	return CPUmodel;
//}
//public void setCPUmodel(String cPUmodel) {
//	CPUmodel = cPUmodel;
//}
//public String getHardiskSize() {
//	return hardiskSize;
//}
//public void setHardiskSize(String hardiskSize) {
//	this.hardiskSize = hardiskSize;
//}
//public String getColor() {
//	return color;
//}
//public void setColor(String color) {
//	this.color = color;
//}
//public model(String name, int year, double price, String cPUmodel, String hardiskSize, String color) {
//	super();
//	this.name = name;
//	this.year = year;
//	this.price = price;
//	CPUmodel = cPUmodel;
//	this.hardiskSize = hardiskSize;
//	this.color = color;
//}
//public model() {
//	super();
//	// TODO Auto-generated constructor stub
//}
// 
//@Override
//public String toString() {
//    return "model{" +
//            "name='" + name + '\'' +
//            ", year=" + year +
//            ", price=" + price +
//            ", cpuModel='" + CPUmodel + '\'' +
//            ", hardDiskSize='" + hardiskSize + '\'' +
//            ", color='" + color + '\'' +
//            '}';
//}
//
//
//}
