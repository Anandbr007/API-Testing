package restAssuredTests;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Endpoints;
import endpoints.Routes;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import payload.model;
import payload.model.Data;

@Listeners(utilities.ExtentReportManager.class)
public class Datatest {

	private model Model;
	Data data;
	int i = 1;

	@BeforeClass
	public void init() {
		    Model = new model();
		    data=new Data();
		    Model.setName("iphone 12");
		    data.setYear(2023);
		    data.setPrice(234.54);
		    data.setCpuModel("intel i9");
	        data.setHardDiskSize("5 TB");
	        data.setColor("blue");
	}

	// Test case to create an data
	@Test(priority = 1)
	public void testCreateData() {
		Response res = Endpoints.createData(Model);
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to get all datas
	@Test(priority = 2)
	public void testgetAllData() {
		Response res = Endpoints.getAllData();
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to get a single data by ID
	@Test(priority = 3)
	public void testgetSingleData() {
		Response res = Endpoints.getSingleData(7);
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to update a data using json payload
	@Test(priority = 5)
	public void testUpdateData() {
		Response res = Endpoints.updateData("ff8081818feaa6c4019005d90b7a26f6");
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to delete a data
	@Test(priority = 6)
	public void testDeleteData() {
		Response res = Endpoints.deleteData("ff8081818feaa6c4019005d90b7a26f6");
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}
	//test case to get invalid data
	@Test(priority=7)
	public void testGetDatabyId()
	{
	
	   Response response = Endpoints.getSingleData(7);
	   response.then().log().all();
	   assertEquals(response.getStatusCode(),200);
	}
	//test case to delete invalid data
	@Test(priority=8)
	public void testDeleteDatabyID()
	{
	
	       Response response = Endpoints.deleteData("ff8081818feaa6c4019005df004326ff");
	       response.then().log().all();
	       assertEquals(response.getStatusCode(),200);
	}


}


