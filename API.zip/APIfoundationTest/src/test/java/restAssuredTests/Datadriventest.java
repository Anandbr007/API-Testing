package restAssuredTests;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import endpoints.Endpoints;
import io.restassured.response.Response;
import payload.model;
import payload.model.Data;
import utilities.DataProviders;

public class Datadriventest {
	@Test(dataProvider ="data" , dataProviderClass = DataProviders.class)
	public void testCreateObject(String name , String year , String price , String cpumodel,String harddisk,String color) {
	    int year1 = Integer.parseInt(year);
	    double prices = Double.parseDouble(price);

	    model  Model = new model();
	    Data data=new Data();
	    Model.setName(name);
	    data.setYear(year1);
	    data.setPrice(prices);
	    data.setCpuModel(cpumodel);
        data.setHardDiskSize(harddisk);
        data.setColor(color);
        
	    Response response = Endpoints.createData(Model);

	    response.then().log().all();
	    assertEquals(response.getStatusCode(), 200);
	}
}

























































