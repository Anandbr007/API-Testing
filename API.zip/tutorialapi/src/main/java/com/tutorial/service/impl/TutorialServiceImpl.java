package com.tutorial.service.impl;

import com.tutorial.model.Tutorial;
import com.tutorial.repository.TutorialRepository;
import com.tutorial.service.TutorialService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TutorialServiceImpl implements TutorialService {

    private final TutorialRepository tutorialRepository;
    static List<Tutorial> tutorials = new ArrayList<Tutorial>();
    static long id;

    public TutorialServiceImpl(TutorialRepository tutorialRepository) {
        this.tutorialRepository = tutorialRepository;
    }

    public Tutorial findTutorialById(Long id) {
        Optional<Tutorial> optionalTutorial = tutorialRepository.findById(id);

        if (optionalTutorial.isPresent()) {
            return optionalTutorial.get();
        } else {
            throw new IllegalArgumentException("Tutorial not found for id: " + id);
        }
    }

    public List<Tutorial> findAll() {
        return tutorialRepository.findAll();
    }

    public List<Tutorial> findByTitleContaining(String title) {
        return tutorials.stream().filter(tutorial -> tutorial.getTitle().contains(title)).toList();
    }

//    public Tutorial findById(long id) {
//        return tutorials.stream().filter(tutorial -> id == tutorial.getId()).findAny().orElse(null);
//    }

    public Tutorial createTutorial(Tutorial tutorial) {
        return tutorialRepository.save(tutorial);
    }


    public void deleteById(long id) {
        tutorialRepository.deleteById(id);
    }

    public void deleteAll() {
        tutorialRepository.deleteAll();
    }

    public List<Tutorial> findByPublished(boolean isPublished) {
        return tutorials.stream().filter(tutorial -> isPublished == tutorial.isPublished()).toList();
    }


}

