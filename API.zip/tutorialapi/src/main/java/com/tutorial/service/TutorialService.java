package com.tutorial.service;

import com.tutorial.model.Tutorial;
import com.tutorial.repository.TutorialRepository;

import java.util.List;
import java.util.Optional;

public interface TutorialService {

    Tutorial findTutorialById(Long id);

    List<Tutorial> findAll();

    List<Tutorial> findByTitleContaining(String title);

    Tutorial createTutorial(Tutorial tutorial);

    void deleteById(long id);

    void deleteAll();

    List<Tutorial> findByPublished(boolean isPublished);

}