package com.tutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutorialRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
