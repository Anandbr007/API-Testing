package tests;


import com.intuit.karate.junit5.Karate;

public class JUnit5Runner {
	@Karate.Test
	Karate KarateTest() {
		return Karate.run("classpath:tests/Sampletest.feature").relativeTo(getClass());
	}
}
