package restassured;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import java.io.File;
public class ValidateResponse {

	RequestSpecification requestSpecification;
	Response response;
	ValidatableResponse validatableresponse;
	@Test
	public void getMethod() {
		String url="https://reqres.in/api/users";
		RestAssured.baseURI=url;
		RestAssured.given().relaxedHTTPSValidation()
				.queryParam("page", "2").contentType("application/json")
				.when().get()
				.then().log().all()
				.assertThat().statusCode(200)
				.assertThat().statusLine("HTTP/1.1 200 OK")
				.assertThat().header("content-type", "application/json")
							.header("Connection", "keep-alive")
				.assertThat().body("page", equalTo(2));
				
		//print the response
		Response res=RestAssured.get(url);
		System.out.println(res.asString());
		
	}
	
	@Test
	public void verifystatuscode() {
		String url="https://reqres.in/api/users?page=2";
		//create a request specification
		requestSpecification=given();
		//calling the get method
		response=requestSpecification.get();
		//lets print the response body
		String resString=response.prettyPrint();
		System.out.println(resString);
		//to perform validation on response we need to get validatatble response
		validatableresponse=response.then();
		ResponseBody resBody=response.getBody();
		System.out.println(resBody.asString());
		//get status code
		validatableresponse.statusCode(200);
	}
	
	@Test
	public void testcase2() {
		RestAssured.given().baseUri("Xn/api/users?page=2")
		.when().get().then().statusCode(200);
	}
	@Test
	public void postRequest() {
		File payload=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\payload.json");
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
					.baseUri("https://restful-booker.herokuapp.com/auth")
					.contentType(ContentType.JSON)
					.body(payload)
					.when().post()
					.then().assertThat()
					.statusCode(200)
					.body("token", Matchers.notNullValue())
					.body("token.length()", Matchers.is(15))
					.body("token", Matchers.matchesRegex("^[a-zA-Z0-9]+$"));
	}
	@Test
	public void putRequest() {
		File payload=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\payloadPut.json");
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
					.baseUri("https://restful-booker.herokuapp.com/auth")
					.contentType(ContentType.JSON)
					.body(payload)
					.when().put()
					.then().assertThat()
					.statusCode(200);
//					.body("token", Matchers.notNullValue())
//					.body("token.length()", Matchers.is(15))
//					.body("token", Matchers.matchesRegex("^[a-zA-Z0-9]+$"));
	}
	
	@Test
	public void putRequest2() {
		File payload=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\payloadPut.json");
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
					.baseUri("https://reqres.in/api/users/2")
					.contentType(ContentType.JSON)
					.body(payload)
					.when().put()
					.then().assertThat()
					.statusCode(200)
					.body("updatedAt",Matchers.startsWith("2024-04-17"));
	}
	
	@Test
	public void patchRequest() {
		File payload=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\payloadPatch.json");
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
					.baseUri("https://reqres.in/api/users/2")
					.contentType(ContentType.JSON)
					.body(payload)
					.when().patch()
					.then().assertThat()
					.statusCode(200);
					
					
	}

}
