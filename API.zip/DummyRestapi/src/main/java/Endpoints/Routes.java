package Endpoints;


public class Routes {


	public static String baseuri="https://dummy.restapiexample.com/";
	public static String get_basePath="api/v1/employees";
	public static String post_basePath="api/v1/create";
	public static String getUnique_basePath="api/v1/employee/{id}";
	public static String delete_basePath="api/v1/delete/{id}";
	public static String update_basePath="api/v1/update/{id}";
}
