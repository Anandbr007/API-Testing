package APItest;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import Endpoints.EmployeeEndpoint;
import Payload.Employee_modal;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;

public class EmployeeTest {

	private Faker faker;
	private Employee_modal payload;
	
	@BeforeClass
	public void setup() {
		payload=new Employee_modal();
		faker=new Faker();
		payload.setId(1);
		payload.setEmployee_name(faker.name().fullName());
		payload.setEmployee_age(faker.number().numberBetween(18, 60));
		payload.setEmployee_salary(faker.number().numberBetween(20000, 1000000));
		payload.setProfile_image("");
	}
	
	 @Test(priority = 1)
	 public void testPostuser() {
		 try {
			 Response response=EmployeeEndpoint.createUser(this.payload);
			 response.then().log().all();
			 Assert.assertEquals(response.getStatusCode(),200);
		} catch (Exception e) {
			// TODO: handle exception
			testPostuser();
		}

	 }
	 
	 @Test(priority = 2)
	 public void testGetuser() {
		 try {
			 Response response=EmployeeEndpoint.getUser(this.payload.getId());
			 response.then().log().all();
			 Assert.assertEquals(response.getStatusCode(),200);
		} catch (Exception e) {
			// TODO: handle exception
			testGetuser();
		}
	
	 }
	 
	 @Test(priority = 3)
	    public void testUpdateuser()
	    {
		 try {
			 faker = new Faker();
    		 payload = new Employee_modal();
    	        
    	        // Update data using payload	    	        
    		 	Long updatedId= (long) 2653;
    			payload.setEmployee_name(faker.name().fullName());
    			payload.setEmployee_age(faker.number().numberBetween(18, 60));
    			payload.setEmployee_salary(faker.number().numberBetween(20000, 1000000));
    			payload.setProfile_image("");
    	        
    	        // Update user using UserEndPoints.updateUser()
    	        Response response = EmployeeEndpoint.updateUser(updatedId, payload);
    	        response.then().log().all();
    	        Assert.assertEquals(response.getStatusCode(), 200);

    	        // Checking data after updation
//    	        Response responseAfterUpdate = BookEndpoints.getUser(updatedId);
//    	        responseAfterUpdate.then().log().all();
//    	        Assert.assertEquals(responseAfterUpdate.getStatusCode(), 200);

    	        // Validate the updated data
//    	        Book_modal updatedUser = responseAfterUpdate.getBody().as(Book_modal.class);
//    	        Assert.assertEquals(bookPayload.getTitle(), updatedTitle);
//    	        Assert.assertEquals(bookPayload.getDescription(), updatedDescription);
//    	        Assert.assertEquals(bookPayload.getPageCount(), updatedPageCount);
//    	        Assert.assertEquals(bookPayload.getExcerpt(), updatedExcerpt);
//    	        Assert.assertEquals(bookPayload.getPublishDate(), updatedPublishDate);
		} catch (Exception e) {
			// TODO: handle exception
			testUpdateuser();
		}
	    		
	    }
	    @Test(priority = 4)
	    public void testDeleteUser()
	    {
	    	try {
	    		  	Response response = EmployeeEndpoint.deleteUser(this.payload.getId());
	  	        	response.then().log().all();
	  	        	Assert.assertEquals(response.getStatusCode(),200);
			} catch (Exception e) {
				testDeleteUser();
			}
	      
	    }
	    
	    @Test(priority = 5)
	    public void schemavalidation() {
	    	try {
	    		String filepath=System.getProperty("user.dir") + "\\src\\test\\resources\\schema.json";
		    	for (int i = 1; i <= 5; i++) {
		    		 Response response=EmployeeEndpoint.getUser(i);
					 response.then().log().all()
					 .assertThat()
					 .body(JsonSchemaValidator.matchesJsonSchema(new File(filepath)));
				}
			} catch (Exception e) {
				schemavalidation();
			}
	    	
	    	
	    }
	
}
