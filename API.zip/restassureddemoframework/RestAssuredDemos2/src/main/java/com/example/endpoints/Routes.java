package com.example.endpoints;

public class Routes {

	public static String baseuri="https://gorest.co.in/";
	public static String post_basePath="/public/v2/users";
	public static String get_basePath="/public/v2/users/{userid}";
	public static String delete_basePath="/public/v2/users/{userid}";
	public static String update_basePath="/public/v2/users/{userid}";
	
}
