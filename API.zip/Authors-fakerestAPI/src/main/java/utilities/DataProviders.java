package utilities;

import java.io.IOException;

import org.testng.annotations.DataProvider;

public class DataProviders {

    // DataProvider method to provide test data from an Excel file
    @DataProvider(name="data")
    public String[][] getAllData() throws IOException{
        // Path to the Excel file
        String path = System.getProperty("user.dir") + "//testdata//data.xlsx";

        // Create an instance of XLutility to handle Excel operations
        XLutility xl = new XLutility(path);

        // Get the number of rows and columns in the Excel sheet
        int rownum = xl.getRowCount("Sheet1");
        int colnum = xl.getCellCount("Sheet1", 1);

        // Create a 2D array to store test data
        String[][] data = new String[rownum][colnum];

        // Loop through each row and column to read test data from Excel
        for (int i = 1; i <= rownum; i++) {
            for (int j = 0; j < colnum; j++) {
                // Read cell data and store it in the array
                data[i - 1][j] = xl.getCellData("Sheet1", i, j);
            }
        }
        // Return the test data array
        return data;
    }
}
