package payLoad;

public class Author_model {

    // Fields representing author attributes
    private int id;             // Author ID
    private int idbook;         // ID of the book associated with the author
    private String firstname;   // Author's first name
    private String lastname;    // Author's last name

    // Default constructor
    public Author_model(){
        
    }

    // Parameterized constructor
    public Author_model(int id, int idbook, String firstname, String lastname) {
        super();
        this.id = id;
        this.idbook = idbook;
        this.firstname = firstname;
        this.lastname = lastname;
    }

    // Getter and setter methods for each field
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdbook() {
        return idbook;
    }

    public void setIdbook(int idbook) {
        this.idbook = idbook;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    // Override toString() method to provide a string representation of the object
    @Override
    public String toString() {
        return "Author_model [id=" + id + ", idbook=" + idbook + ", firstname=" + firstname + ", lastname=" + lastname
                + "]";
    }   
}
