package endPoints;

public class Author_routes {

    // Base URI for the API
    public static String BASE_URI = "https://fakerestapi.azurewebsites.net";

    // Endpoint to get all authors
    public static String GET_BASE_PATH = "/api/v1/Authors";

    // Endpoint to get a single author by ID
    public static String GET_BASE_PATH_AUTHOR = "/api/v1/Authors/{id}";

    // Endpoint to get a single author with their associated book by book ID
    public static String GET_BASE_PATH_BOOK = "/api/v1/Authors/authors/books/{idBook}";

    // Endpoint to create a new author
    public static String POST_BASE_PATH = "/api/v1/Authors";

    // Endpoint to update an existing author by ID
    public static String UPDATE_BASE_PATH_AUTHOR = "/api/v1/Authors/{id}";

    // Endpoint to delete an author by ID
    public static String DELETE_BASE_PATH_AUTHOR = "/api/v1/Authors/{id}";

}
