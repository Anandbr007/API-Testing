package endPoints;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payLoad.Author_model;

public class Author_endpoints {

    // Method to create a new author
    public static Response createAuthor(Author_model payload) {
        RestAssured.useRelaxedHTTPSValidation();
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Author_routes.BASE_URI)
                .basePath(Author_routes.POST_BASE_PATH)
                .accept(ContentType.JSON)
                .body(payload)
                .when()
                .post();
        return response;
    }

    // Method to get all authors
    public static Response getAllAuthor() {
        RestAssured.useRelaxedHTTPSValidation();
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Author_routes.BASE_URI)
                .basePath(Author_routes.GET_BASE_PATH)
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
    }

    // Method to get a single author by ID
    public static Response getSingleAuthor(int id) {
        RestAssured.useRelaxedHTTPSValidation();
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Author_routes.BASE_URI)
                .basePath(Author_routes.GET_BASE_PATH_AUTHOR)
                .pathParam("id", id)
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
    }

    // Method to get a single author with their associated book by book ID
    public static Response getSingleAuthorWithBook(int bookid) {
        RestAssured.useRelaxedHTTPSValidation();
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Author_routes.BASE_URI)
                .basePath(Author_routes.GET_BASE_PATH_BOOK)
                .pathParam("idBook", bookid)
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
    }

    // Method to update an existing author by ID
    public static Response updateAuthor(int id) {
        File payload1=new File(System.getProperty("user.dir")+"\\src\\main\\java\\payLoad\\payload.json");
        RestAssured.useRelaxedHTTPSValidation();
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Author_routes.BASE_URI)
                .basePath(Author_routes.GET_BASE_PATH_AUTHOR)
                .pathParam("id", id)
                .accept(ContentType.JSON)
                .body(payload1)
                .when()
                .put();
        return response;
    }

    // Method to delete an author by ID
    public static Response deleteAuthor(int id) {
        RestAssured.useRelaxedHTTPSValidation();
        Response response = RestAssured.given()
                .header("Content-Type", "application/json")
                .baseUri(Author_routes.BASE_URI)
                .basePath(Author_routes.GET_BASE_PATH_AUTHOR)
                .pathParam("id", id)
                .when()
                .delete();
        return response;
    }
}
