package restapiTestcase;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import endPoints.Author_endpoints;
import io.restassured.response.Response;
import payLoad.Author_model;
import utilities.DataProviders;

public class Datadriventest {

    // Test method to create an author using data from Excel
    @Test(dataProvider ="data" , dataProviderClass = DataProviders.class)
    public void testCreateAuthor(String id1 , String bookid1 , String fname , String lname) {
        // Convert data from String to Integer where necessary
        int id = Integer.parseInt(id1);
        int bookid = Integer.parseInt(bookid1);

        // Create an instance of Author_model with the test data
        Author_model  author = new Author_model();
        author.setId(id);
        author.setIdbook(bookid);
        author.setFirstname(fname);
        author.setLastname(lname);

        // Send a request to create the author using the Author_endpoints class
        Response response = Author_endpoints.createAuthor(author);

        // Log the response and assert the status code
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
    }
}
