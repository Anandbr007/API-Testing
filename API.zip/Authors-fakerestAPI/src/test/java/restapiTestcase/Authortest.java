package restapiTestcase;

import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


import endPoints.Author_endpoints;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import payLoad.Author_model;

@Listeners(utilities.ExtentReportManager.class)
public class Authortest {

	private Author_model author;
	int i = 1;

	// Method to set up test data before test execution
	@BeforeClass
	public void init() {
		author = new Author_model();
		author.setId(1);
		author.setIdbook(1);
		author.setFirstname("alen");
		author.setLastname("posh");
	}

	// Test case to create an author
	@Test(priority = 1)
	public void testCreateAuthor() {
		Response res = Author_endpoints.createAuthor(author);
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to get all authors
	@Test(priority = 2)
	public void testgetAllAuthor() {
		Response res = Author_endpoints.getAllAuthor();
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to get a single author by ID
	@Test(priority = 3)
	public void testgetSingleAuthor() {
		Response res = Author_endpoints.getSingleAuthor(author.getId());
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to get a single author with their associated book by book ID
	@Test(priority = 4)
	public void testgetSingleAuthorWithBook() {
		Response res = Author_endpoints.getSingleAuthorWithBook(author.getIdbook());
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to update an author using json payload
	@Test(priority = 5)
	public void testUpdateAuthor() {
		Response res = Author_endpoints.updateAuthor(author.getId());
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to delete an author
	@Test(priority = 6)
	public void testDeleteAuthor() {
		Response res = Author_endpoints.deleteAuthor(author.getId());
		res.then().log().all();
		assertEquals(res.getStatusCode(), 200);
	}

	// Test case to validate response against JSON schema
	@Test(priority = 7)
	public void testSchemavalidation() {
		File schema = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\Schema.json");
			Response res = Author_endpoints.getSingleAuthor(i);
			res.then().log().all().assertThat().body(JsonSchemaValidator.matchesJsonSchema(schema));
	}
}
