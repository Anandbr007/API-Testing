package karateTestcase;

import com.intuit.karate.junit5.Karate;

public class Author_runner {
    // This method runs the Karate test specified in Karatetest.feature
    @Karate.Test
    public Karate Karatetest() {
        return Karate.run("classpath:karateTestcase/Karatetest.feature").relativeTo(getClass());
    }
}
